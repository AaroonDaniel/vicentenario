<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('etnias', function (Blueprint $table) {
            $table->id('id_etnia'); // Clave primaria personalizada
            $table->string('nombre', 100)->comment('Nombre de la etnia');
            $table->text('descripcion')->nullable()->comment('Descripción detallada de la etnia');

            // Relación con Culturas
            $table->foreignId('id_cultura')
                  ->constrained('culturas', 'id_cultura')
                  ->onDelete('cascade');

            // Timestamps
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('etnias');
    }
};