<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Evento extends Model
{
    use HasFactory;

    // Especificar la clave primaria personalizada
    protected $primaryKey = 'id_evento';

    // Especificar el nombre de la tabla
    protected $table = 'eventos';

    // Desactivar timestamps si no se usan (opcional)
    public $timestamps = true;

    // Definir los campos que se pueden llenar masivamente
    protected $fillable = [
        'nombre',
        'fecha',
        'descripcion',
        'tipo',
        'direccion',
        'departamento',
    ];

    // Relaciones

    // Relación muchos a muchos con Expositores
    public function expositores()
    {
        return $this->belongsToMany(Expositor::class, 'eventos_expositores', 'id_evento', 'id_expositor')
                    ->withPivot('fecha', 'tema') // Incluye las columnas adicionales
                    ->withTimestamps();       // Incluye created_at y updated_at
    }

    // Relación muchos a muchos con Patrocinador
    public function patrocinadores()
    {
        return $this->belongsToMany(Patrocinador::class, 'eventos_patrocinadores', 'id_evento', 'id_auspiciador')
            ->withPivot('fecha', 'monto')
            ->withTimestamps();
    }

    // Relación muchos a muchos con User (participantes)
    public function participantes()
    {
        return $this->belongsToMany(User::class, 'participantes_eventos', 'id_evento', 'user_id')
            ->withPivot('rol', 'confirmado')
            ->withTimestamps();
    }

    // Relación uno a muchos con Agendas
    public function agendas()
    {
        return $this->hasMany(Agenda::class, 'id_evento', 'id_evento');
    }
}
